import json

count = 0
with open('Sample-2-Tweets.json') as data_file:
    for row in data_file:   
        data = json.loads(row)
        count= count +1
        print("created at: "+data['createdAt']['$date'])
        print("Geo-Location "+str(data['geoLocation']['latitude']))
        print("Tweet Text "+data['text'])
        print("Place Name: "+data['place']['name'])
        print("Place Full Name: "+data['place']['fullName'])
        print(" ...... Next Record ........")

print("Counter "+str(count))







