# Script to generate the elements
# in table 2 in exercise 8
for i in range(0,10):
    for j in range(0,10):
        print (i*j) % 10,
    print
