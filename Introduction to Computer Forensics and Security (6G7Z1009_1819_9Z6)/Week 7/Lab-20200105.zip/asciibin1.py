# asciibin.py -- reads a printable character and
# outputs its decimal and binary ascii code
character = raw_input('Input a printable character: ')
acharacter = ord(character)
bits = ''
for i in range(7):
    if(acharacter & pow(2,i) == 0):
        bits = '0' + bits
    else:
        bits = '1' + bits
print 'The character %c has a decimal ascii code of %d\n\
and a 7 bit binary code of %s' % (character, acharacter, bits)
