# asciibin2.py -- reads a printable character and
# outputs its decimal and binary ascii code
import time
character = raw_input('Input a printable character: ')
acharacter = ord(character)
bits = ''
t1=time.clock()
mask=1
for i in range(7):
    if(acharacter & mask == 0):
       bits = bits+'0'
    else:
       bits = bits+'1'
    mask <<= 1
t2=time.clock()
print t2-t1
print 'The character %c has a decimal ascii code of %d\n\
and a 7 bit binary code of %s' % (character, acharacter, bits)

